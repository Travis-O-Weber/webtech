<?php
include 'functions.php';  

echo '<section id="home">';
if (!isset($_POST['submit'])) {
    // Display the registration form if no form has been submitted
    echo '<h2>Please fill out the following to create an account.</h2>';
    echo '<form method="post" action="" id="mainForm" style="padding:20px; margin:20px;">';
    echo '<div class="form-group">';
    echo '<label class="control-label" for="username">Username: </label>';
    echo '<input type="text" id="username" name="username" class="form-control" required />';
    echo '<div id="unFeedback"></div>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label class="control-label" for="password">Password: </label>';
    echo '<input type="password" id="password" name="password" class="form-control" required />';
    echo '<div id="pwFeedback"></div>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<button class="btn btn-primary" type="submit" value="submit" name="submit">Submit</button>';
    echo '</div>';
    echo '</form>';
} elseif (isset($_POST['submit'])) {
    // Process the submitted form
    $username = $_POST['username'];
    $password = $_POST['password'];
    $dblink = db_connect("user_data");

    // Check for existing username
    $sql = "SELECT id FROM accounts WHERE username = ?";
    $stmt = $dblink->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo '<div>Username already taken. Please try another.</div>';
        $stmt->close();
    } else {
        $stmt->close();
        // Insert the new user if username is unique
        $salt = "x2ab2c"; 
        $password_hash = hash('sha256', $salt . $password . $username);
        $insertSql = "INSERT INTO `accounts` (`username`, `auth_hash`) VALUES (?, ?)";
        $insertStmt = $dblink->prepare($insertSql);
        $insertStmt->bind_param("ss", $username, $password_hash);
        if ($insertStmt->execute()) {
            $insertStmt->close();
            redirect("index.php?page=login&success=1");  
        } else {
            echo "Error: " . $insertStmt->error;
            $insertStmt->close();
        }
    }
    $dblink->close();
}
echo '</section>';
?>