<?php
include 'functions.php';  // Assuming db_connect and redirect are defined here

echo '<section id="home">';
if (!isset($_POST['submit'])) {
    // Display the login form
    echo '<h2>Please enter your login credentials.</h2>';
    echo '<form method="post" action="" id="mainForm" style="padding:20px; margin:20px;">';
    echo '<div class="form-group">';
    echo '<label class="control-label" for="username">Username: </label>';
    echo '<input type="text" id="username" name="username" class="form-control" required />';
    echo '<div id="usernameFeedback"></div>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label class="control-label" for="password">Password: </label>';
    echo '<input type="password" id="password" name="password" class="form-control" required />';
    echo '<div id="passwordFeedback"></div>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<button class="btn btn-primary" type="submit" value="submit" name="submit">Submit</button>';
    echo '</div>';
    echo '</form>';
    echo '</section>';
} elseif (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $salt = "x2ab2c";
    $password_hash = hash('sha256', $salt . $password . $username);

    $dblink = db_connect("user_data");

    // Validate username and password
    $sql = "SELECT `auto_id`, `auth_hash` FROM `accounts` WHERE `username` = ?";
    $stmt = $dblink->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($password_hash == $row['auth_hash']) {
            // Create new session ID and store it in the database
            $new_salt = microtime();
            $new_sid = hash('sha256', $new_salt . $username);

            $updateSql = "UPDATE `accounts` SET `session_id` = ? WHERE `username` = ?";
            $updateStmt = $dblink->prepare($updateSql);
            $updateStmt->bind_param("ss", $new_sid, $username);
            if ($updateStmt->execute()) {
                $updateStmt->close();
                redirect("results.php?sid=$new_sid");
            } else {
                echo "Failed to update session. Please try again.";
            }
        } else {
            echo '<div>Invalid username or password.</div>';
        }
    } else {
        echo '<div>Invalid username or password.</div>';
    }
    $stmt->close();
    $dblink->close();
}
?>